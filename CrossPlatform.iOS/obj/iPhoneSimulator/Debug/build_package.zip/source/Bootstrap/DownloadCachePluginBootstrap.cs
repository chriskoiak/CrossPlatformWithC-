using Cirrious.CrossCore.Plugins;

namespace CrossPlatform.iOS.Bootstrap
{
    public class DownloadCachePluginBootstrap
        : MvxLoaderPluginBootstrapAction<Cirrious.MvvmCross.Plugins.DownloadCache.PluginLoader, Cirrious.MvvmCross.Plugins.DownloadCache.Touch.Plugin>
    {
    }
}